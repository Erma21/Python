#name = ("Артём")
#last_name = (" Гордиенко")
#my_age = (" 16")
#print(name +  last_name +  my_age)

#myAge = input("Введите свой возраст:")
#print("Ваш возраст:",myAge)

#a = True
#print(a)

#b = False
#print(b)


#my_age = 16
#print("Возраст:", my_age)

#my_count = 1337
#print("Количество:", my_count)

#myH = 1.71
#pi = 3.14
#myW = 63
#print(myH, myW, pi)

import math
a = int(input())
z1 = 1-(1/4)*math.pow(math.sin(2*a),2)+math.cos(2*a)
z2 = math.pow(math.cos(a),2)+math.pow(math.cos(a),4)
print(z1,  z2)