#name = ("Артём")
#last_name = (" Гордиенко")
#my_age = (" 16")
#print(name +  last_name +  my_age)

#myAge = input("Введите свой возраст:")
#print("Ваш возраст:",myAge)

#a = True
#print(a)

#b = False
#print(b)


#my_age = 16
#print("Возраст:", my_age)

#my_count = 1337
#print("Количество:", my_count)

#myH = 1.71
#pi = 3.14
#myW = 63
#print(myH, myW, pi)

#import math
#a = int(input())
#z1 = 1-(1/4)*math.pow(math.sin(2*a),2)+math.cos(2*a)
#z2 = math.pow(math.cos(a),2)+math.pow(math.cos(a),4)
#print(z1,  z2)

#import math
#a = -2
#b = 0.8
#h = 0.2
#while a < b:
#    z = a*math.cos(math.pi/4)-math.pow(a, 2)
#    k = a*1-2*math.cos(math.pi/4)+math.pow(a, 2)
 #   y = z/k
#    a += h
 #   print(y)
# import math
# summ = 0
#  a = 0.1
#  b = 1.0
#  h = 0.1
#  while a <= b:
#   s = 0.1*math.cos(0,1 += 1)/math.factorial(a)


# while True:
#     try:
#         number1, operation, number2 = [
#                 i for i in
#                 input(
#                     'Введите математическое выражение (число операнд число): '
#                     ).split()
#                 ]
#     except ValueError:
#         print('Неправильный ввод.')
#         continue
#     number1 = int(number1)
#     number2 = int(number2)
#
#     if operation == '0':
#         break
#     elif operation == '+':
#         print(f'{number1} {operation} {number2} = {number1 + number2}')
#     elif operation == '-':
#         print(f'{number1} {operation} {number2} = {number1 - number2}')
#     elif operation == '*':
#         print(f'{number1} {operation} {number2} = {number1 * number2}')
#     elif operation == '/':
#         try:
#             print(f'{number1} {operation} {number2} = {number1 / number2}')
#         except ZeroDivisionError:
#             print('Ошибка. Деление на ноль')




# number = input("Ведите число:")
#
# even_numbered = 0
# odd_numbered = 0
#
# for z in number:
#     i = int(z)
#     if i % 2 == 0:
#         even_numbered =+ 1
#     else:
#         odd_numbered =+ 1
# print(f"У числа {number},четных цифр - {even_numbered},нечетных цифр - {odd_numbered}")

